import AppKit
import WebKit

private let defaultState = FileManager.default.homeDirectoryForCurrentUser
    .appendingPathComponent(".local/state/taik-factory", isDirectory: true)

private struct Round: Codable {
    let name: String
    let fields: [String: String]
    let detail: String

    init?(file: URL) {
        guard let info = try? file.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]),
              info.isRegularFile == true, info.isSymbolicLink != true,
              let size = info.fileSize, size <= 8_192,
              let text = try? String(contentsOf: file, encoding: .utf8), text.hasSuffix("end\n") else { return nil }
        var fields: [String: String] = [:]
        for line in text.split(separator: "\n") {
            let pair = line.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            if pair.count == 2 { fields[String(pair[0])] = String(pair[1]) }
        }
        guard let decision = fields["decision"], ["accepted", "rejected"].contains(decision) else { return nil }
        name = file.lastPathComponent
        self.fields = fields
        detail = text
    }
}

private struct Job: Codable {
    let id: String
    let baseline: Round
    let rounds: [Round]
    let progress: [String: [ProgressEvent]]
    let sourceActive: Bool
    let sourceStartedAt: Double?

    var pending: Bool {
        if baseline.fields["kind"] == "software" { return sourceActive }
        guard let last = rounds.last else { return true }
        return last.fields["advance"] == "true" && rounds.count < 20
    }
}

private struct ProgressEvent: Codable {
    let elapsed: UInt64
    let kind: String
    let detail: String

    static func read(_ url: URL) -> [Self] {
        guard let info = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]),
              info.isRegularFile == true, info.isSymbolicLink != true,
              let size = info.fileSize, size <= 32_768,
              let contents = try? String(contentsOf: url, encoding: .utf8) else { return [] }
        return contents.split(separator: "\n", omittingEmptySubsequences: false).dropLast().compactMap { line in
            let fields = line.split(separator: "\t", maxSplits: 2, omittingEmptySubsequences: false)
            guard fields.count == 3, let elapsed = UInt64(fields[0]) else { return nil }
            return Self(elapsed: elapsed, kind: String(fields[1]), detail: String(fields[2]))
        }
    }
}

private struct Snapshot: Codable {
    let jobs: [Job]
    let pending: Int
    let service: String
    let pid: Int32?
}

private final class FactoryMonitor {
    private let state: URL
    private let onChange: (String) -> Void
    private var directories: [URL: DispatchSourceFileSystemObject] = [:]
    private var serviceExit: DispatchSourceProcess?
    private var servicePID: Int32?
    private var lastSnapshot: String?

    init(state: URL, onChange: @escaping (String) -> Void) {
        self.state = state
        self.onChange = onChange
    }

    func refresh(watch: Bool) {
        let queue = state.appendingPathComponent("jobs", isDirectory: true)
        if watch {
            watchPath(state)
            watchPath(queue)
            watchPath(state.appendingPathComponent("service-error.log"))
        }
        let jobURLs = latestJobs(in: queue)
        if watch { for url in jobURLs { watchPath(url) } }
        let progressByJob = Dictionary(uniqueKeysWithValues: jobURLs.map { ($0, progressFiles(in: $0)) })
        if watch {
            let progressFiles = progressByJob.values.flatMap { $0 }
            for url in progressFiles { watchPath(url) }
            let retained = Set(jobURLs + progressFiles + [state, queue, state.appendingPathComponent("service-error.log")])
            for url in Array(directories.keys) where !retained.contains(url) { stopWatching(url) }
        }
        let jobs = jobURLs.compactMap { readJob($0, progressByJob[$0] ?? []) }
        let pid = runningService()
        if watch { watchServiceExit(pid) }
        let snapshot = Snapshot(
            jobs: jobs, pending: jobs.filter(\.pending).count,
            service: state == defaultState ? (pid == nil ? "offline" : "running") : "unmanaged", pid: pid
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        guard let data = try? encoder.encode(snapshot), let json = String(data: data, encoding: .utf8),
              json != lastSnapshot else { return }
        lastSnapshot = json
        onChange(json)
    }

    private func latestJobs(in queue: URL) -> [URL] {
        let keys: Set<URLResourceKey> = [.isDirectoryKey, .isSymbolicLinkKey, .creationDateKey]
        let entries = (try? FileManager.default.contentsOfDirectory(
            at: queue, includingPropertiesForKeys: Array(keys), options: [.skipsHiddenFiles]
        )) ?? []
        let dated = entries.compactMap { url -> (URL, Date)? in
            guard url.lastPathComponent.hasPrefix("job-"),
                  let values = try? url.resourceValues(forKeys: keys),
                  values.isDirectory == true, values.isSymbolicLink != true else { return nil }
            return (url, values.creationDate ?? .distantPast)
        }
        return dated.sorted { first, second in
            if first.1 == second.1 { return first.0.lastPathComponent > second.0.lastPathComponent }
            return first.1 > second.1
        }.prefix(12).map(\.0)
    }

    private func progressFiles(in url: URL) -> [URL] {
        let entries = (try? FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)) ?? []
        return entries.filter {
            let basename = $0.deletingPathExtension().lastPathComponent
            return $0.pathExtension == "progress" && basename.hasPrefix("round-")
                && (1...20).contains(Int(basename.dropFirst(6)) ?? 0)
        }
    }

    private func readJob(_ url: URL, _ progressFiles: [URL]) -> Job? {
        guard let baseline = Round(file: url.appendingPathComponent("baseline.run"))
            ?? Round(file: url.appendingPathComponent("request.run")),
              baseline.fields["decision"] == "accepted" else { return nil }
        var rounds: [Round] = []
        for index in 1...20 {
            let name = String(format: "round-%02d.run", index)
            guard let round = Round(file: url.appendingPathComponent(name)) else { break }
            rounds.append(round)
        }
        let progress = Dictionary(uniqueKeysWithValues: progressFiles.map {
            ($0.deletingPathExtension().lastPathComponent, ProgressEvent.read($0))
        })
        let next = String(format: "round-%02d", rounds.count + 1)
        let active = baseline.fields["kind"] == "software" && progress[next] != nil
            && isLocked(url.appendingPathComponent("source.lock"))
        let startedAt = active ? (try? url.appendingPathComponent(next + ".brief.md")
            .resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate?.timeIntervalSince1970 : nil
        return Job(id: url.lastPathComponent, baseline: baseline, rounds: rounds, progress: progress,
            sourceActive: active, sourceStartedAt: startedAt)
    }

    private func isLocked(_ url: URL) -> Bool {
        let fd = open(url.path, O_RDONLY | O_NONBLOCK | O_NOFOLLOW)
        guard fd >= 0 else { return false }
        defer { _ = close(fd) }
        if flock(fd, LOCK_SH | LOCK_NB) == 0 { return false }
        return errno == EWOULDBLOCK
    }

    private func watchPath(_ url: URL) {
        guard directories[url] == nil else { return }
        let descriptor = open(url.path, O_EVTONLY | O_CLOEXEC)
        guard descriptor >= 0 else { return }
        let source = DispatchSource.makeFileSystemObjectSource(
            fileDescriptor: descriptor, eventMask: [.write, .delete, .rename, .revoke], queue: .main
        )
        source.setEventHandler { [weak self, weak source] in
            guard let self, let source else { return }
            if !source.data.intersection([.delete, .rename, .revoke]).isEmpty { self.stopWatching(url) }
            self.refresh(watch: true)
        }
        source.setCancelHandler { _ = close(descriptor) }
        directories[url] = source
        source.resume()
    }

    private func stopWatching(_ url: URL) {
        directories.removeValue(forKey: url)?.cancel()
    }

    private func runningService() -> Int32? {
        guard state == defaultState else { return nil }
        let command = Process()
        command.executableURL = URL(fileURLWithPath: "/bin/launchctl")
        command.arguments = ["print", "gui/\(getuid())/local.taik.factory"]
        let pipe = Pipe()
        command.standardOutput = pipe
        command.standardError = FileHandle.nullDevice
        guard (try? command.run()) != nil else { return nil }
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        command.waitUntilExit()
        guard command.terminationStatus == 0, let text = String(data: data, encoding: .utf8) else { return nil }
        for line in text.split(separator: "\n") {
            let field = line.trimmingCharacters(in: .whitespaces)
            if field.hasPrefix("pid = ") { return Int32(field.dropFirst(6)) }
        }
        return nil
    }

    private func watchServiceExit(_ pid: Int32?) {
        guard pid != servicePID else { return }
        serviceExit?.cancel()
        serviceExit = nil
        servicePID = pid
        guard let pid else { return }
        let source = DispatchSource.makeProcessSource(identifier: pid, eventMask: .exit, queue: .main)
        source.setEventHandler { [weak self] in
            self?.servicePID = nil
            self?.serviceExit?.cancel()
            self?.serviceExit = nil
            self?.refresh(watch: true)
        }
        serviceExit = source
        source.resume()
    }
}

private func scriptSafe(_ json: String) -> String {
    json.replacingOccurrences(of: "<", with: "\\u003c")
        .replacingOccurrences(of: "\u{2028}", with: "\\u2028")
        .replacingOccurrences(of: "\u{2029}", with: "\\u2029")
}

private final class FactoryWindow: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKScriptMessageHandler {
    private let state: URL
    private let fragment: String
    private var window: NSWindow!
    private var webView: WKWebView!
    private var monitor: FactoryMonitor!
    private var snapshot = "null"
    private var loaded = false

    init(state: URL, fragment: String) {
        self.state = state
        self.fragment = fragment
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 850, height: 790),
            styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false
        )
        window.title = "TAIK Factory"
        window.minSize = NSSize(width: 375, height: 320)
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.userContentController.add(self, name: "openArtifact")
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        window.contentView = webView
        installMenu()
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        monitor = FactoryMonitor(state: state) { [weak self] json in
            self?.snapshot = json
            self?.renderChanges()
        }
        monitor.refresh(watch: true)
        let content = fragment.replacingOccurrences(of: "/*FACTORY_DATA*/null", with: scriptSafe(snapshot))
        webView.loadHTMLString("""
        <!doctype html><html lang="de"><meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <style>html{color-scheme:light dark}body{margin:0;padding:clamp(16px,4vw,35px);background:#f8fafc;color:#1b293b;font-family:system-ui}@media(prefers-color-scheme:dark){body{background:#101923;color:#edf3ff}}</style>
        <title>TAIK Factory</title>\(content)</html>
        """, baseURL: nil)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        loaded = true
        renderChanges()
    }

    private func renderChanges() {
        guard loaded else { return }
        webView.evaluateJavaScript("window.updateFactory(\(scriptSafe(snapshot)))")
    }

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "openArtifact", let body = message.body as? [String: String],
              let job = body["job"], job.hasPrefix("job-"), !job.contains("/"),
              let name = body["name"], name.range(of: #"^round-[0-9]{2}\.html$"#, options: .regularExpression) != nil else { return }
        let directory = state.appendingPathComponent("jobs", isDirectory: true).appendingPathComponent(job, isDirectory: true)
        let artifact = directory.appendingPathComponent(name)
        let record = artifact.deletingPathExtension().appendingPathExtension("run")
        guard let round = Round(file: record), round.fields["decision"] == "accepted", round.fields["artifact"] == name else { return }
        NSWorkspace.shared.open(artifact)
    }

    private func installMenu() {
        let menu = NSMenu()
        let app = NSMenuItem()
        app.submenu = NSMenu()
        app.submenu?.addItem(withTitle: "Beenden", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        menu.addItem(app)
        NSApp.mainMenu = menu
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

let arguments = CommandLine.arguments
let state = arguments.firstIndex(of: "--state").flatMap { arguments.indices.contains($0 + 1) ? arguments[$0 + 1] : nil }
    .map { URL(fileURLWithPath: $0, isDirectory: true).standardizedFileURL } ?? defaultState
let fragmentPath = Bundle.main.url(forResource: "factory-view", withExtension: "html")
    ?? URL(fileURLWithPath: #filePath).deletingLastPathComponent().appendingPathComponent("factory-view.html")

if arguments.contains("--stream") {
    let monitor = FactoryMonitor(state: state) { json in print(json); fflush(stdout) }
    monitor.refresh(watch: true)
    withExtendedLifetime(monitor) { dispatchMain() }
} else {
    let fragment = try String(contentsOf: fragmentPath, encoding: .utf8)
    if arguments.contains("--snapshot") {
        FactoryMonitor(state: state) { json in
            print(fragment.replacingOccurrences(of: "/*FACTORY_DATA*/null", with: scriptSafe(json)))
        }.refresh(watch: false)
    } else {
        let app = NSApplication.shared
        let controller = FactoryWindow(state: state, fragment: fragment)
        app.delegate = controller
        app.setActivationPolicy(.regular)
        withExtendedLifetime(controller) { app.run() }
    }
}

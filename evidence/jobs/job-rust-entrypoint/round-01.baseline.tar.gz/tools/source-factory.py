"""One bounded source-code round using the signed-in Codex worker."""
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import fcntl

LIMIT = 96 * 1024
PROJECT = Path(__file__).resolve().parents[1]

def publish(path, value):
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".pending-", delete=False) as output:
        temp = Path(output.name)
        try:
            output.write(value.encode())
            output.flush()
            os.fsync(output.fileno())
            os.link(temp, path)
        finally:
            temp.unlink(missing_ok=True)

def sandbox(profile, scratch, *command):
    return ["/usr/bin/sandbox-exec", "-D", "WORK=" + str(scratch), "-D", "PROJECT=" + str(PROJECT), "-p", profile, *command]

def worker(scratch, prompt, note):
    codex = shutil.which("codex")
    if codex is None:
        raise RuntimeError("Codex executable unavailable")
    home = scratch / "codex-home"
    home.mkdir()
    native = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex")) / "auth.json"
    (home / "auth.json").symlink_to(native.resolve(strict=True))
    env = {key: os.environ[key] for key in ("PATH", "HOME", "LANG", "USER", "LOGNAME") if key in os.environ}
    env.update(CODEX_HOME=str(home), TMPDIR=str(scratch), NODE_DISABLE_COMPILE_CACHE="1")
    restricted = '(version 1) (allow default) (deny file-write*) (allow file-write* (subpath (param "WORK"))) (deny file-read* (subpath (param "PROJECT")))'
    base = sandbox(restricted, scratch, codex)
    auth = subprocess.run([*base, "login", "status"], cwd=scratch, env=env, text=True, capture_output=True, timeout=5)
    if auth.returncode or "Logged in using ChatGPT" not in (auth.stdout + auth.stderr):
        raise RuntimeError("An active ChatGPT subscription session is required")
    result = scratch / "message.html"
    cmd = [*base, "-a", "never", "exec", "--ignore-user-config", "--ignore-rules", "--skip-git-repo-check",
           "--ephemeral", "--sandbox", "read-only", "--color", "never", "--json",
           "--disable", "shell_tool", "--disable", "unified_exec", "--disable", "shell_snapshot",
           "--disable", "plugins", "--disable", "hooks", "--disable", "multi_agent",
           "--enable", "skip_host_skill_discovery", "-c", 'web_search="disabled"',
           "-c", 'model_reasoning_effort="low"', "--output-last-message", str(result), "--", prompt]
    deadline = time.monotonic() + 150
    with (scratch / "worker-stderr").open("wb") as stderr:
        child = subprocess.Popen(cmd, cwd=scratch, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=stderr, start_new_session=True)
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout, selectors.EVENT_READ)
                buffer = b""
                while True:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0 or not selector.select(remaining):
                        raise TimeoutError("Codex deadline reached")
                    data = os.read(child.stdout.fileno(), 65536)
                    if not data:
                        break
                    buffer += data
                    if len(buffer) > 2 * LIMIT:
                        raise RuntimeError("Codex event exceeds byte limit")
                    while b"\n" in buffer:
                        line, buffer = buffer.split(b"\n", 1)
                        try:
                            event = json.loads(line)
                        except (ValueError, UnicodeError):
                            continue
                        kind = event.get("type", "event")
                        item = event.get("item") or {}
                        note("worker", str(kind) + ("/" + item["type"] if "type" in item else ""))
            if child.wait(timeout=max(0.1, deadline - time.monotonic())):
                diagnostic = (scratch / "worker-stderr").read_text(errors="replace").splitlines()
                raise RuntimeError(diagnostic[-1][:300] if diagnostic else "Codex exited without a successful source response")
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            child.stdout.close()
    if not result.is_file() or result.stat().st_size > LIMIT:
        raise RuntimeError("No source within the declared byte limit")
    html = result.read_text().strip()
    fence = chr(96) * 3
    if html.startswith(fence):
        html = html.split("\n", 1)[1].rsplit("\n" + fence, 1)[0]
    return html + "\n"

def verify(directory, gate, continued):
    (directory / "gate.mjs").write_text(gate)
    node = shutil.which("node")
    if node is None:
        raise RuntimeError("Node executable unavailable")
    profile = '(version 1) (allow default) (deny network*) (deny file-write*) (allow file-write* (subpath (param "WORK"))) (deny file-read* (subpath (param "PROJECT")))'
    command = sandbox(profile, directory, node, directory / "gate.mjs", directory / "candidate.html", "follow-up" if continued else "initial")
    return subprocess.run(command, cwd=directory, env={"PATH": os.environ["PATH"]}, text=True, capture_output=True, timeout=15)

def read_attached(note):
    chunks = []
    total = 0
    deadline = time.monotonic() + 150
    with selectors.DefaultSelector() as selector:
        selector.register(sys.stdin, selectors.EVENT_READ)
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not selector.select(remaining):
                raise TimeoutError("Attached worker deadline reached")
            chunk = os.read(sys.stdin.fileno(), 4096)
            if not chunk:
                break
            total += len(chunk)
            if total > LIMIT:
                raise RuntimeError("Attached worker exceeded source byte limit")
            chunks.append(chunk)
            note("worker", f"{total} Bytes Quellcode vom Worker empfangen")
    return b"".join(chunks).decode()

def run(job, brief_path, gate_path, attached=False):
    job.mkdir(parents=True, exist_ok=True)
    with (job / "source.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return evaluate(job.resolve(), brief_path, gate_path, attached)

def evaluate(job, brief_path, gate_path, attached):
    rounds = sorted(job.glob("round-*.run"))
    number = len(rounds) + 1
    if number > 4:
        raise RuntimeError("Four-round job budget exhausted")
    gate = gate_path.read_text()
    digest = hashlib.sha256(gate.encode()).hexdigest()
    locked = job / "gate.sha256"
    if locked.exists() and locked.read_text().strip() != digest:
        raise RuntimeError("This job requires the same independent gate")
    if not locked.exists():
        publish(locked, digest + "\n")
    if not (job / "request.run").exists():
        publish(job / "request.run", "decision=accepted\nkind=software\nprocedure=\ntags=\nend\n")
    accepted = [r.with_suffix(".html") for r in rounds if r.read_text().startswith("decision=accepted\n")]
    baseline = accepted[-1] if accepted else None
    index = f"round-{number:02d}"
    started = time.monotonic_ns()
    stream = job / (index + ".progress")
    brief = brief_path.read_text()
    if not brief.strip() or len(brief.encode()) > 8192:
        raise RuntimeError("Brief is empty or exceeds input limit")
    archived = job / (index + ".brief.md")
    if archived.exists():
        if archived.read_text() != brief:
            raise RuntimeError("Interrupted round requires its original brief")
    else:
        publish(archived, brief)

    def note(kind, value):
        value = value.replace("\r", " ").replace("\n", " ").replace("\t", " ")[:1000]
        micros = (time.monotonic_ns() - started) // 1000
        with stream.open("a") as out:
            out.write(f"{micros}\t{kind}\t{value}\n")
        print(f"{index} {kind} {value}", flush=True)

    decision = "rejected"
    evidence = ""
    note("start", "Factory hat den Auftrag übernommen")
    try:
        with tempfile.TemporaryDirectory(prefix="taik-code-") as temp:
            scratch = Path(temp).resolve()
            previous = baseline.read_text() if baseline else "(empty)"
            if len(previous.encode()) > LIMIT:
                raise RuntimeError("Accepted source exceeds input limit")
            prompt = "You are the code worker embedded in TAIK. The trusted verifier runs separately. " \
                     "Return only one complete standalone HTML document, no fences or explanation.\n\n" \
                     f"WORK ORDER:\n{brief}\n\nACCEPTED SOURCE TO BUILD ON:\n{previous}"
            note("worker", "Eingehängter Codex-Worker liefert Quellcode" if attached else "Codex erhält Auftrag und akzeptierten Ausgangsstand")
            html = read_attached(note) if attached else worker(scratch, prompt, note)
            (scratch / "candidate.html").write_text(html)
            note("evaluate", "Die Factory führt die unveränderte unabhängige Prüfung aus")
            result = verify(scratch, gate, baseline is not None)
            if result.returncode:
                diagnostic = (result.stdout + result.stderr).splitlines()
                evidence = next((line for line in diagnostic if "Error:" in line), "Verifier exited with " + str(result.returncode))[:500]
            else:
                evidence = result.stdout.strip()[:4000]
            note("checks", evidence.strip() or f"Exit {result.returncode}")
            if result.returncode == 0:
                publish(job / (index + ".html"), html)
                decision = "accepted"
    except (OSError, RuntimeError, ValueError, TimeoutError, subprocess.TimeoutExpired) as error:
        evidence = str(error)
        note("error", evidence)
    evidence = evidence.replace("\n", " ").replace("\r", " ")[:4000]
    artifact = index + ".html" if decision == "accepted" else ""
    next_step = ("Use the accepted artifact in the next justified round, or run it locally."
                 if decision == "accepted" else "Retain the previous accepted source and inspect the failed evidence.")
    worker_name = "codex-attached" if attached else "codex-subscription"
    record = f"decision={decision}\nkind=software\nprocedure=\ntags=\nidentity={index}\nintent={brief.splitlines()[0]}\nbaseline={baseline or '(empty)'}\nworker={worker_name}\nlimits=four rounds; worker 150s; verifier 15s; 96KiB source\ngate_sha256={digest}\nchecks={evidence}\nartifact={artifact}\ncontinuation={next_step}\nadvance=false\nend\n"
    publish(job / (index + ".run"), record)
    note(decision, f"{artifact} {next_step}".strip())
    return 0 if decision == "accepted" else 1

if __name__ == "__main__":
    args = sys.argv[1:]
    attached = bool(args and args[-1] == "--attached")
    sys.exit(run(*map(Path, args[:-1] if attached else args), attached=attached))

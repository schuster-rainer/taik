"""Run the optional v0.4 experiments against the existing Rust factory CLI."""
from pathlib import Path
import json
import re
import subprocess
import sys
import time

BASE = Path("evidence/jobs/job-tag-prozedur/01-seed.run")
CLI = Path("target/debug/taik-seed")
TRAIN = (
    ("  ACORN ", "acorn", " "),
    ("\tMAIZE", "ORE", "  "),
    ("  ROOT ", "ROOT", "\t "),
)
HELD = (
    (" SEED ", "seed", " "),
    ("   PEAR  ", "QUINCE", "\t"),
    ("\tD-19", "d-19", " LIME "),
    ("rock", "birch-7", "rock"),
    ("TEA", "BARK", "tea"),
    ("  ", "\t", " "),
)

def main(output):
    output.mkdir(exist_ok=True)
    observations = []

    def execute(name, command, baseline, *args):
        candidate = output / (name + ".run")
        start = time.perf_counter_ns()
        result = subprocess.run([CLI, command, baseline, candidate, *args], check=True, text=True, capture_output=True, timeout=10)
        elapsed = time.perf_counter_ns() - start
        fields = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
        work = tuple(int(n) for n in re.findall(r":(\d+)", fields["artifact_work"]))
        observations.append(dict(name=name, path=str(candidate), operation=command, source=str(baseline), elapsed_ns=elapsed, work=work, tags=fields["tags"]))
        print(name, fields["decision"], work, elapsed, flush=True)
        return candidate, observations[-1]

    first, _ = execute("ga-producer", "evolve", BASE)
    enlarged, b = execute("ga-consumer", "extend", first, "  FIR ", " ASH ", "  ")
    second, a = execute("ga-feedback", "evolve", enlarged)
    assert b["tags"] == a["tags"] == "ash,cedar,fir"
    alternate, _ = execute("learn-producer", "evolve", first)
    choices = [BASE, first, alternate]
    train_costs = []
    for index, baseline in enumerate(choices):
        series = [execute(f"train-{index}-{i}", "extend", baseline, *tags)[1] for i, tags in enumerate(TRAIN)]
        train_costs.append([sum(row["work"][j] for row in series) for j in range(2)])
    winner = min(range(len(choices)), key=lambda i: train_costs[i])
    learned = output / "learned-selector.json"
    learned.write_text(json.dumps(dict(execute="extend", baseline=str(choices[winner]), observed_training_costs=train_costs), indent=2) + "\n")
    policy = json.loads(learned.read_text())
    held = []
    for index, tags in enumerate(HELD):
        _, original = execute(f"held-old-{index}", "extend", BASE, *tags)
        _, retained = execute(f"held-learned-{index}", policy["execute"], policy["baseline"], *tags)
        prefix, generate = execute(f"fresh-1-{index}", "evolve", BASE)
        fresh, verify = execute(f"fresh-2-{index}", "evolve", prefix)
        _, fresh_row = execute(f"fresh-use-{index}", "extend", fresh, *tags)
        assert retained["tags"] == original["tags"] == fresh_row["tags"]
        held.append(dict(original_ns=original["elapsed_ns"], reuse_ns=retained["elapsed_ns"], rediscover_ns=sum(row["elapsed_ns"] for row in (generate, verify, fresh_row)), original_work=original["work"], retained_work=retained["work"], tags=retained["tags"]))
    setup = sum(row["elapsed_ns"] for row in observations if row["name"].startswith(("ga-", "train-", "learn-")))
    summary = dict(
        producer=str(first), consumer=str(enlarged), feedback=str(second), policy=str(learned),
        setup_ns=setup, reused_total_ns=setup + sum(row["reuse_ns"] for row in held),
        rederived_total_ns=sum(row["rediscover_ns"] for row in held),
        original_total_ns=sum(row["original_ns"] for row in held), held=held, observations=observations,
    )
    (output / "results.json").write_text(json.dumps(summary, indent=2) + "\n")
    print("Done", {key: value for key, value in summary.items() if key.endswith("_ns")}, flush=True)

if __name__ == "__main__":
    main(Path(sys.argv[1]))

use std::fs::{self, File};
use std::io::{self, Write};
use std::os::fd::AsRawFd;
use std::os::unix::fs::DirBuilderExt;
use std::path::{Path, PathBuf};

use crate::queue_events::QueueEvents;
use crate::{
    MAX_RECORD_BYTES, Outcome, Result, evolve_progress, procedure::Search, progress::Progress,
    record, self_improve,
};

const MAX_ROUNDS: usize = 20;

fn jobs_in(state: &Path) -> Result<PathBuf> {
    let jobs = state.join("jobs");
    fs::DirBuilder::new()
        .recursive(true)
        .mode(0o700)
        .create(&jobs)?;
    Ok(jobs.canonicalize()?)
}

pub fn queue(state: &Path, baseline: &Path) -> Result<PathBuf> {
    if baseline.extension().is_none_or(|ext| ext != "run") {
        return Err("a queued baseline must be a published .run file".into());
    }
    let source = record::read_regular(baseline, MAX_RECORD_BYTES)?;
    record::parse_accepted(&source)?;
    let jobs = jobs_in(state)?;
    let job = stage(&jobs)?;
    let mut origin = File::create(job.path().join("origin.txt"))?;
    writeln!(origin, "source={:?}", baseline.canonicalize()?)?;
    origin.sync_all()?;
    record::publish(&job.path().join("baseline.run"), &source)?;
    let name = job.path().file_name().unwrap().to_string_lossy();
    let published = jobs.join(name.trim_start_matches('.'));
    publish_job(job, published)
}

pub fn queue_self(state: &Path) -> Result<PathBuf> {
    let jobs = jobs_in(state)?;
    let job = stage(&jobs)?;
    record::publish(&job.path().join("request.run"), self_improve::REQUEST)?;
    publish_job(job, jobs.join(self_improve::JOB))
}

#[cfg(target_os = "macos")]
pub fn queue_source(state: &Path, name: &str, brief: &Path, gate: &Path) -> Result<PathBuf> {
    if name.is_empty()
        || name.len() > 48
        || !name
            .bytes()
            .all(|byte| byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'-')
    {
        return Err("use a short job name with lowercase ASCII letters, digits or hyphens".into());
    }
    let destination = format!("job-{name}");
    if destination == self_improve::JOB {
        return Err("reserved self-improvement job name".into());
    }
    let brief = record::read_regular(brief, MAX_RECORD_BYTES)?;
    crate::source::intent(&brief)?;
    let gate = record::read_regular(gate, crate::source::LIMIT)?;
    if gate.trim().is_empty() {
        return Err("source jobs require a nonempty verification gate".into());
    }
    let jobs = jobs_in(state)?;
    let job = stage(&jobs)?;
    record::publish(&job.path().join("submission.brief.md"), &brief)?;
    record::publish_text(
        &job.path().join("submission.gate.mjs"),
        &gate,
        crate::source::LIMIT,
    )?;
    record::publish(&job.path().join("request.run"), crate::source::REQUEST)?;
    publish_job(job, jobs.join(destination))
}

fn stage(jobs: &Path) -> Result<tempfile::TempDir> {
    Ok(tempfile::Builder::new()
        .prefix(".job-")
        .tempdir_in(jobs.parent().unwrap())?)
}

fn publish_job(job: tempfile::TempDir, published: PathBuf) -> Result<PathBuf> {
    if published.symlink_metadata().is_ok() {
        return Err(format!("job already exists: {}", published.display()).into());
    }
    // Readiness and the kernel wake-up are the same filesystem operation.
    fs::rename(job.path(), &published)?;
    let _ = job.keep();
    if let Err(error) = File::open(published.parent().unwrap()).and_then(|dir| dir.sync_all()) {
        eprintln!(
            "queued {}, directory sync failed: {error}",
            published.display()
        );
    }
    Ok(published)
}

pub fn run(state: &Path, continuous: bool) -> Result<bool> {
    let jobs = jobs_in(state)?;
    let state = jobs.parent().unwrap();
    let lock = File::options()
        .create(true)
        .truncate(false)
        .write(true)
        .open(state.join("service.lock"))?;
    // The lock is released by the OS if the daemon is killed.
    if unsafe { libc::flock(lock.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 {
        return Err("another Factory worker holds this state directory".into());
    }
    let mut events = continuous.then(|| QueueEvents::watch(&jobs)).transpose()?;
    if events.is_some() {
        eprintln!("watching for jobs in {}", jobs.display());
    }
    loop {
        let succeeded = drain(&jobs)?;
        let Some(events) = events.as_mut() else {
            return Ok(succeeded);
        };
        events.wait()?;
    }
}

fn drain(jobs: &Path) -> Result<bool> {
    let mut entries = fs::read_dir(jobs)?.collect::<io::Result<Vec<_>>>()?;
    entries.sort_unstable_by_key(fs::DirEntry::file_name);
    let (search, mut succeeded) = self_improve::drive(&jobs.join(self_improve::JOB))?;
    for entry in entries {
        if !entry.file_type()?.is_dir() {
            continue;
        }
        let job = entry.path();
        if job.join("baseline.run").is_file() {
            match run_job(&job, search) {
                Ok(accepted) => succeeded &= accepted,
                Err(error) => {
                    eprintln!("{}: {error}", entry.path().display());
                    succeeded = false;
                }
            }
        }
        #[cfg(target_os = "macos")]
        if job.join("submission.brief.md").is_file() && !job.join("round-01.run").try_exists()? {
            match crate::source::run(
                &job,
                &job.join("submission.brief.md"),
                &job.join("submission.gate.mjs"),
                false,
            ) {
                Ok(accepted) => succeeded &= accepted,
                Err(error) => {
                    eprintln!("{}: {error}", job.display());
                    succeeded = false;
                }
            }
        }
    }
    Ok(succeeded)
}

fn run_job(job: &Path, search: Search) -> Result<bool> {
    let mut baseline = job.join("baseline.run");
    for index in 1..=MAX_ROUNDS {
        let target = job.join(format!("round-{index:02}.run"));
        let outcome = match target.symlink_metadata() {
            Ok(_) => read_outcome(&target)?,
            Err(error) if error.kind() == io::ErrorKind::NotFound => {
                let mut progress = Progress::for_round(&target);
                let outcome = evolve_progress(&baseline, &target, search, &mut progress);
                if let Err(error) = &outcome {
                    progress.event("error", format_args!("{error:?}"));
                }
                outcome?
            }
            Err(error) => return Err(error.into()),
        };
        if !outcome.advance {
            return Ok(outcome.accepted);
        }
        baseline = target;
    }
    Err(format!(
        "job reached the {MAX_ROUNDS}-round bound; its last accepted record is {}",
        baseline.display()
    )
    .into())
}

fn read_outcome(path: &Path) -> Result<Outcome> {
    let text = record::read_regular(path, MAX_RECORD_BYTES)?;
    if !text.ends_with("end\n") {
        return Err("published round is incomplete".into());
    }
    if text.starts_with("decision=accepted\n") {
        record::parse_accepted(&text)?;
        let advance = match text.lines().find_map(|line| line.strip_prefix("advance=")) {
            Some("true") => true,
            Some("false") => false,
            _ => return Err("published round lacks a continuation decision".into()),
        };
        Ok(Outcome {
            accepted: true,
            advance,
        })
    } else if text.starts_with("decision=rejected\n") {
        Ok(Outcome {
            accepted: false,
            advance: false,
        })
    } else {
        Err("published round lacks an outcome".into())
    }
}

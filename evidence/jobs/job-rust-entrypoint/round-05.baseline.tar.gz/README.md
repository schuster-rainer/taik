# TAIK seed experiment

The seed creates a sorted list of unique ASCII tags and retains the executable normalization order alongside it. The initial `seed` command starts from an empty list. `extend` loads and invokes a retained procedure in a later process. `evolve` proposes one measured change to the procedure. `serve` accepts durable jobs and applies bounded rounds until the evidence supports retaining the current result.

## Run

From this directory, with Rust 2024 support and a local filesystem that supports hard links:

```sh
cargo build --offline --locked
run_dir=$(mktemp -d)
seed=target/debug/taik-seed

"$seed" seed "$run_dir/seed.run"
"$seed" reject "$run_dir/seed.run" "$run_dir/rejected.run" || test "$?" -eq 1
"$seed" extend "$run_dir/seed.run" "$run_dir/extended.run" '  ELM ' ' ASH' '  '
"$seed" refine "$run_dir/extended.run" "$run_dir/refined.run"
"$seed" extend "$run_dir/extended.run" "$run_dir/baseline-replay.run" \
  $'   BIRCH-2\t' $' \tPINE  ' 'birch-2' $' \t ' ' ELM '
"$seed" extend "$run_dir/refined.run" "$run_dir/refined-reuse.run" \
  $'   BIRCH-2\t' $' \tPINE  ' 'birch-2' $' \t ' ' ELM '
```

Exit codes are `0` for acceptance, `1` for an evaluated rejection, and `2` for an invocation or file error. Published `.run` files are create-only. A `.pending` file left by an interruption is ineligible as a baseline. A retry can use a fresh output name and the last accepted record.

## Watch continuous work

The macOS LaunchAgent `local.taik.factory` runs the local worker in `~/.local/state/taik-factory` while the user session is available. It starts on login and is supervised by launchd.

The actual job files live in [evidence/jobs](evidence/README.md). The runtime job path points to the same directory. New `origin.txt` entries reference inputs within `jobs/` relative to the job folder.

Open **TAIK Factory** from `~/Applications` to follow it. From a checkout, `./tools/open-factory-view.sh` builds and installs the macOS viewer. The window follows the latest job by default and updates on filesystem events. An active round shows its current work and recent events. **Arbeitsschritte** expands the full trace for a published round, and **Prüfprotokoll** opens its decision record. Short rounds can finish before the next display refresh, and their steps remain available in the trace.

The right column has two fixed panes. **Ergebnis** shows the published Floorplanner. **Zum Auftrag** follows the selected job and shows its output, source draft or checks. When the selected job produced the result above, the lower pane shows its source. HTML runs in an offline Web Component and reloads when a new round is accepted. The viewer watches local files and makes no model calls. Only a verified artifact runs in the preview.

**Darstellung** offers System, Hell and Dunkel and remembers the choice in the macOS app. The viewer sets the frame's color scheme and sends a `taik-appearance` message with the resolved `appearance` (`light` or `dark`) to the embedded document. The Floorplanner redraws its Canvas in place and follows the browser's preference when opened directly. Result documents own their palette and can handle the message when they need to redraw.

The offline preview check opens the retained Floorplanner, checks highlighting, switches between light and dark, and verifies that the Canvas redraws, an edit survives and network access is blocked:

```sh
"$HOME/Applications/TAIK Factory.app/Contents/MacOS/factory-view" --snapshot |
  swift tools/check-floorplanner-preview.swift
```

To follow the raw decisions in a terminal:

```sh
state="$HOME/.local/state/taik-factory"
tail -f "$state/service.log"
```

Job directories under `jobs/` contain `origin.txt`, `baseline.run`, and a `.run` record for every evaluated round. New rounds also write a bounded `.progress` trace while they run. The `.run` record is the stored acceptance decision. To hand off a new accepted baseline, run `"$state/taik-seed" queue "$state" /path/to/accepted.run`. The queue stages the complete job before atomically moving it into `jobs/`. The directory event wakes the worker. Each accepted improvement immediately becomes the next baseline. At convergence the worker blocks on the kernel until another job arrives. On restart it checks the queue and resumes from the published records. `drain STATE` runs the same job logic once for a state directory without an active service.

The proposal boundary is a list of existing operation names. `evaluate BASELINE.run OUTPUT.run ORDER` accepts an explicit candidate as data and uses the same independent gate as `evolve`. The local search evaluates at most 20 one-step relocations. An improved candidate must preserve canonical output and the required operation dependencies, and must reduce one measured kind of work without increasing the other. Every job has a 20-round cap. The loop advances only after an accepted improvement.

## Execute and observe

| Run | Observed result and decision | Evidence |
| --- | --- | --- |
| Seed | Added raw tags, sorted canonical forms, reduced duplicates and checked output. Accepted `ash,cedar` with `lower-then-trim`. | [01-seed.run](evidence/jobs/job-tag-prozedur/01-seed.run) |
| Drop lowercasing | The retained tags still passed. The mixed-case probe yielded `ELM,OAK,oak` instead of `elm,oak`. Rejected. The accepted seed record was byte-for-byte identical afterward. | [02-rejected.run](evidence/jobs/job-tag-prozedur/02-rejected.run) |
| Restart and extend | A fresh process loaded the original tags and procedure. It accepted `ash,cedar,elm` from a batch containing a new tag, a duplicate and a blank. | [03-extended.run](evidence/jobs/job-tag-prozedur/03-extended.run) |
| Reorder the procedure | Moved trimming before lowercasing. Both procedures passed the same fixed probe and the candidate preserved `ash,cedar,elm`. The probe sent 14 bytes to lowercase before the change and 9 after it. Accepted `trim-then-lower`. | [04-refined.run](evidence/jobs/job-tag-prozedur/04-refined.run) |
| Compare on a new batch | Two fresh processes started with the same retained tags. Both accepted `ash,birch-2,cedar,elm,pine`. The original procedure sent 45 input bytes to lowercase and the reused refinement sent 32. | [05-baseline-replay.run](evidence/jobs/job-tag-prozedur/05-baseline-replay.run), [06-refined-reuse.run](evidence/jobs/job-tag-prozedur/06-refined-reuse.run) |

The offline Rust build and Clippy with warnings denied passed. Separate CLI checks verified that the seed refused a staged `.pending` copy, a truncated `.run`, a rejected record, and an attempt to overwrite an accepted record. It also refused nine additions in one invocation, accepted 32 retained tags, then rejected the 33rd while preserving the 32-tag record. Every invocation returned to its caller. There is no idle loop.

## Source-code rounds

Submit an HTML job to the running macOS service with a short job name, a Markdown brief and an independent Node.js gate:

```sh
state="$HOME/.local/state/taik-factory"
"$state/taik-seed" queue-source "$state" mein-auftrag ./brief.md ./verify.mjs
```

The first line of the brief names the round intent. The gate receives the candidate path as `process.argv[2]` and exits successfully only if the acceptance checks pass. The command snapshots both inputs into `evidence/jobs/job-mein-auftrag` and wakes the service. The service runs one source round and records the decision in `round-01.run`. The accepted document is `round-01.html`. Job names are unique.

`taik-seed source JOB BRIEF GATE` starts one bounded source round on macOS with the signed-in Codex subscription. The conversation worker can submit a source document through standard input with `--attached`. The Factory gives the worker the last accepted source, tests the candidate in a separate scratch directory with a Node.js gate, and publishes the output only after that gate passes. The gate is pinned for the lifetime of the job. Each round keeps its brief, progress events and decision beside the accepted executable artifact. The `artifact=` field in the decision record explicitly names that output.

The isometric discounter planner uses `tools/floorplanner/brief.md` and `tools/floorplanner/verify.mjs`. The live Factory window opens its latest accepted standalone HTML from the job. During source work it displays the active phase, elapsed time and actual worker events. The Codex command delivers structured events, with source returned on completion.

`taik-seed queue-self STATE` submits the bounded experiment on the Factory's own tag procedure search. Each verified search policy feeds the next round. Later tag jobs use the retained policy, including after a service restart. The final round records when both candidate reductions have been evaluated.

When the `valid-unique` policy is accepted, the service measures the probe work it still repeats. If that work exists, the service creates the research job `job-suchentscheidungen-wiederverwenden`. It retains one decision per legal order after comparing each with exhaustive search. The service checks the retained decisions again on restart and uses them in later tag jobs. These jobs still run their original output checks.

On macOS, `serve STATE --reflect` also studies whether the work spent verifying that table at startup has an actual consumer. It carries a proposal into separate replay workloads and activates the candidate timing only after the comparisons pass. Both timing rules withhold the table until the original verification has succeeded.

`taik-seed experiment BASELINE.run OUTPUT_DIRECTORY` runs the Galaxy and Intelligence experiment in a new directory. The original measurements and conclusions remain in the [Galaxy and Intelligence job](evidence/jobs/job-galaxy-intelligence/summary.run).

## Reflect and stop

The rejected candidate shows why the retained artifact alone is insufficient to evaluate its producer. Already-canonical tags masked the missing lowercase step. The fixed probe caught it. The first runs also exposed a narrower procedure change worth testing. Moving trimming earlier reduced the input to lowercasing while satisfying the existing artifact and probe checks. The coding agent supplied the change. The seed evaluated it, retained the accepted procedure, and invoked it again from disk.

The byte counts measure only the input to the lowercase step for the two tested batches. Elapsed time, total resource savings and power-loss recovery were unmeasured. The interruption check used a staged file and a truncated copy. The design assumes trusted local records and a filesystem with hard-link support.

The second batch reproduced the observed reduction and justified testing whether the Factory could derive its own next change. The local worker enumerated single-step relocations of the retained procedure. It first moved trimming ahead of lowercasing, reducing the reference probe from 14 to 9 bytes sent to lowercase. The next round moved blank removal ahead of sorting, reducing the number of items sorted from 4 to 3. A final search found no further accepted one-step improvement on that probe. A fresh process then reapplied the retained procedure to a new batch. An explicit invalid order failed the gate and preserved the accepted procedure. [First local change](evidence/jobs/job-tag-prozedur/07-local-reorder.run) · [Second local change](evidence/jobs/job-tag-prozedur/08-local-reduce.run) · [Retain](evidence/jobs/job-tag-prozedur/09-local-retain.run) · [Reuse](evidence/jobs/job-tag-prozedur/10-local-reuse.run) · [Rejected order](evidence/jobs/job-tag-prozedur/11-invalid-order.run)

`cargo test --offline --locked` verified all 120 operation permutations against the order constraints, compared the seven admitted permutations against an independent reference over 343 three-input samples each, and exercised the FIFO regression, create-only publication, staged records, competing workers, a process restart, and event-driven wake-up. The running macOS service also completed a full three-round job after a supervised replacement. The ordering argument holds for the declared ASCII domain. A power-loss test and validation of the Linux watcher remain outside the executed checks.

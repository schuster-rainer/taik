use std::fs::File;
use std::io::{Read, Seek, Write};
use std::os::fd::{AsRawFd, RawFd};
use std::os::unix::fs::{OpenOptionsExt, symlink};
use std::os::unix::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitStatus, Stdio};
use std::time::{Duration, Instant};
use std::{env, fs, io};

use sha2::{Digest, Sha256};

use crate::{Progress, Result, record};

pub const LIMIT: usize = 96 * 1024;
const ROUNDS: usize = 4;
const WORKER_TIMEOUT: Duration = Duration::from_secs(150);
const GATE_TIMEOUT: Duration = Duration::from_secs(15);
pub const REQUEST: &str = "decision=accepted\nkind=software\nprocedure=\ntags=\nend\n";
const POLICY: &str = r#"(version 1) (allow default) (deny file-write*)
    (allow file-write* (subpath (param "WORK")))
    (deny file-read* (subpath (param "PROJECT")))
    (deny file-read* (subpath (param "JOB")))"#;

pub(crate) fn intent(brief: &str) -> Result<&str> {
    let intent = brief
        .lines()
        .next()
        .filter(|line| !line.trim().is_empty())
        .ok_or("missing round intent")?;
    if intent.len() > 512 {
        return Err("round intent exceeds 512 bytes".into());
    }
    Ok(intent)
}

pub fn run(job: &Path, brief: &Path, gate: &Path, attached: bool) -> Result<bool> {
    let brief = record::read_regular(brief, record::MAX_RECORD_BYTES)?;
    let intent = intent(&brief)?;
    let gate = record::read_regular(gate, LIMIT)?;
    let digest = format!("{:x}", Sha256::digest(gate.as_bytes()));
    fs::create_dir_all(job)?;
    let job = job.canonicalize()?;
    let _lock = lock_job(&job)?;
    pin(&job.join("gate.sha256"), &format!("{digest}\n"))?;
    pin(&job.join("request.run"), REQUEST)?;
    let (number, baseline) = next_round(&job)?;
    let stem = format!("round-{number:02}");
    let output = job.join(format!("{stem}.run"));
    let artifact = format!("{stem}.html");
    pin(&job.join(format!("{stem}.brief.md")), &brief)?;
    let mut progress = Progress::for_round(&output);
    progress.event("start", format_args!("Factory hat den Auftrag übernommen"));
    let scratch_dir = tempfile::tempdir()?;
    let scratch = scratch_dir.path().canonicalize()?;
    let persisted = job.join(&artifact);
    let draft_path = job.join(format!("{stem}.draft"));
    let mut draft = open_draft(&draft_path).ok();

    let execution = (|| -> Result<(bool, String)> {
        let html = if persisted.try_exists()? {
            progress.event(
                "worker",
                format_args!("Unterbrochenen Kandidaten erneut prüfen"),
            );
            record::read_regular(&persisted, LIMIT)?
        } else if attached {
            progress.event(
                "worker",
                format_args!("Eingehängter Codex-Worker liefert Quellcode"),
            );
            let bytes = read_bytes(
                libc::STDIN_FILENO,
                Instant::now() + WORKER_TIMEOUT,
                LIMIT,
                |data| {
                    show_draft(draft.as_mut(), data);
                    progress.event(
                        "worker",
                        format_args!("{} Bytes Quellcode empfangen", data.len()),
                    );
                },
            )?;
            String::from_utf8(bytes)?
        } else {
            let previous = baseline
                .as_ref()
                .map(|path| record::read_regular(path, LIMIT))
                .transpose()?;
            let prompt = format!(
                "You are the code worker embedded in TAIK. Return one complete standalone HTML document, no fences or explanation.\n\nWORK ORDER:\n{brief}\n\nACCEPTED SOURCE TO BUILD ON:\n{}",
                previous.as_deref().unwrap_or("(empty)"),
            );
            progress.event(
                "worker",
                format_args!("Codex erhält Auftrag und akzeptierten Ausgangsstand"),
            );
            let workspace = scratch.join("worker");
            fs::create_dir(&workspace)?;
            codex(&workspace, &job, &prompt, &mut progress, |text| {
                show_draft(draft.as_mut(), text.as_bytes());
            })?
        };
        progress.event(
            "evaluate",
            format_args!("Unabhängiges, gespeichertes Prüfgate ausführen"),
        );
        let verification = scratch.join("verification");
        fs::create_dir(&verification)?;
        let result = verify(&verification, &job, &gate, &html, baseline.is_some())?;
        let valid = result.status.success();
        if valid && !persisted.try_exists()? {
            record::publish_text(&persisted, &html, LIMIT)?;
        }
        let diagnosis = result.diagnosis(valid);
        progress.event("checks", format_args!("{diagnosis}"));
        Ok((valid, diagnosis))
    })();
    let (accepted, checks) = execution.unwrap_or_else(|error| {
        let reason = single_line(&error.to_string());
        progress.event("error", format_args!("{reason}"));
        (false, reason)
    });
    let decision = if accepted { "accepted" } else { "rejected" };
    let artifact = if accepted { artifact.as_str() } else { "" };
    let continuation = if accepted {
        "Run the accepted artifact or supply the next justified brief."
    } else {
        "Retain the previous accepted source and inspect the failed evidence."
    };
    let worker = if attached {
        "codex-attached"
    } else {
        "codex-subscription"
    };
    let baseline = baseline
        .as_deref()
        .map(|p| p.to_string_lossy())
        .unwrap_or("(empty)".into());
    let report = format!(
        "decision={decision}\nkind=software\nprocedure=\ntags=\nidentity={stem}\nintent={intent}\nbaseline={baseline}\nworker={worker}\nlimits={ROUNDS} rounds; worker 150s; verifier 15s; 96KiB source\n\
         gate_sha256={digest}\nchecks={checks}\nartifact={artifact}\ncontinuation={continuation}\nadvance=false\nend\n"
    );
    crate::emit(&output, &report)?;
    if draft.is_some() {
        let _ = fs::remove_file(draft_path);
    }
    progress.event(decision, format_args!("{continuation}"));
    Ok(accepted)
}

fn open_draft(path: &Path) -> io::Result<File> {
    let file = File::options()
        .write(true)
        .create(true)
        .truncate(true)
        .mode(0o600)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
        .open(path)?;
    if !file.metadata()?.is_file() {
        return Err(io::Error::other("expected a regular draft file"));
    }
    Ok(file)
}

fn show_draft(file: Option<&mut File>, contents: &[u8]) {
    if let Some(file) = file.filter(|_| contents.len() <= LIMIT) {
        let _ = file
            .rewind()
            .and_then(|()| file.write_all(contents))
            .and_then(|()| file.set_len(contents.len() as u64));
    }
}

fn lock_job(job: &Path) -> Result<File> {
    let lock = File::options()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
        .open(job.join("source.lock"))?;
    if !lock.metadata()?.is_file() {
        return Err("expected a regular job lock".into());
    }
    if unsafe { libc::flock(lock.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 {
        return Err("this source job already has an active worker".into());
    }
    Ok(lock)
}

fn pin(path: &Path, contents: &str) -> Result<()> {
    if path.try_exists()? {
        if record::read_regular(path, record::MAX_RECORD_BYTES)? != contents {
            return Err(format!("changed pinned input: {}", path.display()).into());
        }
    } else {
        record::publish(path, contents)?;
    }
    Ok(())
}

fn next_round(job: &Path) -> Result<(usize, Option<PathBuf>)> {
    let mut baseline = None;
    for number in 1..=ROUNDS {
        let stem = format!("round-{number:02}");
        let result = job.join(format!("{stem}.run"));
        if !result.try_exists()? {
            return Ok((number, baseline));
        }
        let text = record::read_regular(&result, record::MAX_RECORD_BYTES)?;
        if !text.ends_with("end\n") || !text.lines().any(|line| line == "kind=software") {
            return Err("invalid existing source decision".into());
        }
        if text.starts_with("decision=accepted\n") {
            let name = format!("{stem}.html");
            if !text
                .lines()
                .any(|line| line.strip_prefix("artifact=") == Some(name.as_str()))
            {
                return Err("source decision points to a different artifact".into());
            }
            let artifact = job.join(name);
            record::read_regular(&artifact, LIMIT)?;
            baseline = Some(artifact);
        } else if !text.starts_with("decision=rejected\n") {
            return Err("invalid existing source outcome".into());
        }
    }
    Err("four-round source job budget exhausted".into())
}

fn sandbox(scratch: &Path, job: &Path, program: &str, network: bool) -> Result<Command> {
    let mut command = Command::new("/usr/bin/sandbox-exec");
    let network_rule = if network { "" } else { " (deny network*)" };
    command
        .arg("-D")
        .arg(format!("WORK={}", scratch.display()))
        .arg("-D")
        .arg(format!(
            "PROJECT={}",
            env::current_dir()?.canonicalize()?.display()
        ))
        .arg("-D")
        .arg(format!("JOB={}", job.display()))
        .arg("-p")
        .arg(format!("{POLICY}{network_rule}"))
        .arg(program)
        .current_dir(scratch)
        .env_clear();
    for key in ["PATH", "HOME", "LANG", "USER", "LOGNAME"] {
        if let Some(value) = env::var_os(key) {
            command.env(key, value);
        }
    }
    command
        .env("TMPDIR", scratch)
        .env("NODE_DISABLE_COMPILE_CACHE", "1");
    Ok(command)
}

pub(crate) fn codex(
    scratch: &Path,
    job: &Path,
    prompt: &str,
    progress: &mut Progress,
    mut show_code: impl FnMut(&str),
) -> Result<String> {
    let isolated = scratch.join("codex-home");
    fs::create_dir(&isolated)?;
    let native = match env::var_os("CODEX_HOME") {
        Some(home) => PathBuf::from(home),
        None => PathBuf::from(env::var_os("HOME").ok_or("subscription session requires HOME")?)
            .join(".codex"),
    };
    symlink(
        native.join("auth.json").canonicalize()?,
        isolated.join("auth.json"),
    )?;
    let base = || -> Result<Command> {
        let mut command = sandbox(scratch, job, "codex", true)?;
        command.env("CODEX_HOME", &isolated);
        Ok(command)
    };
    let status = run_child(
        base()?.args(["login", "status"]),
        Duration::from_secs(5),
        |_| {},
    )?;
    if !status.status.success() || !status.text().contains("Logged in using ChatGPT") {
        return Err("an active ChatGPT subscription session is required".into());
    }
    let result = scratch.join("message.txt");
    let mut next_line = 0;
    let response = run_child(
        base()?
            .args([
                "-a",
                "never",
                "exec",
                "--ignore-user-config",
                "--ignore-rules",
                "--skip-git-repo-check",
                "--ephemeral",
                "--sandbox",
                "read-only",
                "--color",
                "never",
                "--json",
                "--disable",
                "shell_tool",
                "--disable",
                "unified_exec",
                "--disable",
                "shell_snapshot",
                "--disable",
                "plugins",
                "--disable",
                "hooks",
                "--disable",
                "multi_agent",
                "--enable",
                "skip_host_skill_discovery",
                "-c",
                "web_search=\"disabled\"",
                "-c",
                "model_reasoning_effort=\"low\"",
                "--output-last-message",
            ])
            .arg(&result)
            .arg("--")
            .arg(prompt),
        WORKER_TIMEOUT,
        |data| {
            while let Some(newline) = data[next_line..].iter().position(|byte| *byte == b'\n') {
                let end = next_line + newline;
                if let Ok(event) =
                    serde_json::from_slice::<serde_json::Value>(&data[next_line..end])
                {
                    let kind = event["type"].as_str().unwrap_or("event");
                    let item = event["item"]["type"].as_str().unwrap_or("");
                    if item == "agent_message"
                        && matches!(kind, "item.updated" | "item.completed")
                        && let Some(code) = event["item"]["text"].as_str()
                    {
                        show_code(code);
                    }
                    progress.event(
                        "worker",
                        format_args!("{}", single_line(&format!("{kind} {item}"))),
                    );
                }
                next_line = end + 1;
            }
        },
    )?;
    if !response.status.success() {
        return Err(format!("Codex exited: {}", response.status).into());
    }
    let source = record::read_regular(&result, LIMIT)?;
    let answer = source.trim();
    let fence = "\u{60}\u{60}\u{60}";
    let answer = if answer.starts_with(fence) {
        answer
            .split_once('\n')
            .and_then(|(_, text)| text.rsplit_once(&format!("\n{fence}")))
            .map(|(text, _)| text)
            .ok_or("incomplete worker response")?
    } else {
        answer
    };
    Ok(format!("{answer}\n"))
}

fn verify(
    scratch: &Path,
    job: &Path,
    gate: &str,
    html: &str,
    continued: bool,
) -> Result<ChildResult> {
    fs::write(scratch.join("gate.mjs"), gate)?;
    fs::write(scratch.join("candidate.html"), html)?;
    run_child(
        sandbox(scratch, job, "node", false)?.args([
            "gate.mjs",
            "candidate.html",
            if continued { "follow-up" } else { "initial" },
        ]),
        GATE_TIMEOUT,
        |_| {},
    )
}

pub(crate) fn single_line(text: &str) -> String {
    text.chars()
        .take(1024)
        .map(|c| if c.is_control() { ' ' } else { c })
        .collect()
}

struct ChildResult {
    status: ExitStatus,
    stdout: Vec<u8>,
    stderr: String,
}

impl ChildResult {
    fn text(&self) -> String {
        format!("{}\n{}", String::from_utf8_lossy(&self.stdout), self.stderr)
    }

    fn diagnosis(&self, success: bool) -> String {
        if success {
            return single_line(String::from_utf8_lossy(&self.stdout).trim());
        }
        self.stderr
            .lines()
            .find(|line| line.contains("Error:"))
            .map(single_line)
            .unwrap_or_else(|| format!("Verifier exited with {}", self.status))
    }
}

fn run_child(
    command: &mut Command,
    timeout: Duration,
    update: impl FnMut(&[u8]),
) -> Result<ChildResult> {
    let deadline = Instant::now() + timeout;
    let mut stderr = tempfile::tempfile()?;
    command
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(stderr.try_clone()?)
        .process_group(0);
    // Only an async-signal-safe system call executes after fork.
    unsafe {
        command.pre_exec(|| {
            let limit = libc::rlimit {
                rlim_cur: 16 * 1024 * 1024,
                rlim_max: 16 * 1024 * 1024,
            };
            if libc::setrlimit(libc::RLIMIT_FSIZE, &limit) != 0 {
                return Err(io::Error::last_os_error());
            }
            Ok(())
        });
    }
    let mut child = command.spawn()?;
    let execution = (|| -> Result<ChildResult> {
        let fd = child
            .stdout
            .as_ref()
            .ok_or("missing worker output")?
            .as_raw_fd();
        let bytes = read_bytes(fd, deadline, 4 * LIMIT, update)?;
        let status = loop {
            if let Some(status) = child.try_wait()? {
                break status;
            }
            if Instant::now() >= deadline {
                return Err("process deadline exceeded".into());
            }
            std::thread::sleep(Duration::from_millis(10));
        };
        stderr.rewind()?;
        let mut diagnostic = Vec::new();
        stderr.take(8192).read_to_end(&mut diagnostic)?;
        Ok(ChildResult {
            status,
            stdout: bytes,
            stderr: String::from_utf8_lossy(&diagnostic).into_owned(),
        })
    })();
    if execution.is_err() {
        unsafe {
            libc::kill(-(child.id() as i32), libc::SIGKILL);
        }
        let _ = child.wait();
    }
    execution
}

fn read_bytes(
    fd: RawFd,
    deadline: Instant,
    limit: usize,
    mut update: impl FnMut(&[u8]),
) -> Result<Vec<u8>> {
    let mut all = Vec::new();
    let mut buffer = [0u8; 4096];
    loop {
        let remaining = deadline.saturating_duration_since(Instant::now());
        if remaining.is_zero() {
            return Err("process deadline exceeded".into());
        }
        let mut signal = libc::pollfd {
            fd,
            events: libc::POLLIN,
            revents: 0,
        };
        let ready = unsafe { libc::poll(&mut signal, 1, remaining.as_millis().max(1) as i32) };
        if ready == 0 {
            return Err("process deadline exceeded".into());
        }
        if ready < 0 {
            let error = io::Error::last_os_error();
            if error.kind() == io::ErrorKind::Interrupted {
                continue;
            }
            return Err(error.into());
        }
        let size = unsafe { libc::read(fd, buffer.as_mut_ptr().cast(), buffer.len()) };
        if size == 0 {
            return Ok(all);
        }
        if size < 0 {
            let error = io::Error::last_os_error();
            if error.kind() == io::ErrorKind::Interrupted {
                continue;
            }
            return Err(error.into());
        }
        let size = size as usize;
        if all.len() + size > limit {
            return Err("worker output exceeded byte limit".into());
        }
        all.extend_from_slice(&buffer[..size]);
        update(&all);
    }
}

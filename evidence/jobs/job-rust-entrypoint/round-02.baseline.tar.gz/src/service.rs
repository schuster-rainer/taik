use std::fs::{self, File};
use std::io::{self, Write};
use std::os::fd::AsRawFd;
use std::os::unix::fs::DirBuilderExt;
use std::path::{Path, PathBuf};

use crate::queue_events::QueueEvents;
use crate::{MAX_RECORD_BYTES, Outcome, Result, evolve_progress, progress::Progress, record};

const MAX_ROUNDS: usize = 20;

fn jobs_in(state: &Path) -> Result<PathBuf> {
    let jobs = state.join("jobs");
    fs::DirBuilder::new()
        .recursive(true)
        .mode(0o700)
        .create(&jobs)?;
    Ok(jobs.canonicalize()?)
}

pub fn queue(state: &Path, baseline: &Path) -> Result<PathBuf> {
    if baseline.extension().is_none_or(|ext| ext != "run") {
        return Err("a queued baseline must be a published .run file".into());
    }
    let source = record::read_regular(baseline, MAX_RECORD_BYTES)?;
    record::parse_accepted(&source)?;
    let jobs = jobs_in(state)?;
    let staging = jobs.parent().unwrap().join("staging");
    fs::DirBuilder::new()
        .recursive(true)
        .mode(0o700)
        .create(&staging)?;
    let job = tempfile::Builder::new()
        .prefix("job-")
        .tempdir_in(&staging)?;
    let mut origin = File::create(job.path().join("origin.txt"))?;
    writeln!(origin, "source={:?}", baseline.canonicalize()?)?;
    origin.sync_all()?;
    record::publish(&job.path().join("baseline.run"), &source)?;
    let published = jobs.join(job.path().file_name().unwrap());
    // Readiness and the kernel wake-up are the same filesystem operation.
    fs::rename(job.keep(), &published)?;
    if let Err(error) = File::open(&jobs).and_then(|dir| dir.sync_all()) {
        eprintln!(
            "queued {}, directory sync failed: {error}",
            published.display()
        );
    }
    Ok(published)
}

pub fn run(state: &Path, continuous: bool) -> Result<bool> {
    let jobs = jobs_in(state)?;
    let state = jobs.parent().unwrap();
    let lock = File::options()
        .create(true)
        .truncate(false)
        .write(true)
        .open(state.join("service.lock"))?;
    // The lock is released by the OS if the daemon is killed.
    if unsafe { libc::flock(lock.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 {
        return Err("another Factory worker holds this state directory".into());
    }
    let mut events = continuous.then(|| QueueEvents::watch(&jobs)).transpose()?;
    if events.is_some() {
        eprintln!("watching for jobs in {}", jobs.display());
    }
    loop {
        let succeeded = drain(&jobs)?;
        let Some(events) = events.as_mut() else {
            return Ok(succeeded);
        };
        events.wait()?;
    }
}

fn drain(jobs: &Path) -> Result<bool> {
    let mut entries = fs::read_dir(jobs)?.collect::<io::Result<Vec<_>>>()?;
    entries.sort_unstable_by_key(fs::DirEntry::file_name);
    let mut succeeded = true;
    for entry in entries {
        if entry.file_type()?.is_dir() && entry.path().join("baseline.run").is_file() {
            match run_job(&entry.path()) {
                Ok(accepted) => succeeded &= accepted,
                Err(error) => {
                    eprintln!("{}: {error}", entry.path().display());
                    succeeded = false;
                }
            }
        }
    }
    Ok(succeeded)
}

fn run_job(job: &Path) -> Result<bool> {
    let mut baseline = job.join("baseline.run");
    for index in 1..=MAX_ROUNDS {
        let target = job.join(format!("round-{index:02}.run"));
        let outcome = match target.symlink_metadata() {
            Ok(_) => read_outcome(&target)?,
            Err(error) if error.kind() == io::ErrorKind::NotFound => {
                let mut progress = Progress::for_round(&target);
                let outcome = evolve_progress(&baseline, &target, &mut progress);
                if let Err(error) = &outcome {
                    progress.event("error", format_args!("{error:?}"));
                }
                outcome?
            }
            Err(error) => return Err(error.into()),
        };
        if !outcome.advance {
            return Ok(outcome.accepted);
        }
        baseline = target;
    }
    Err(format!(
        "job reached the {MAX_ROUNDS}-round bound; its last accepted record is {}",
        baseline.display()
    )
    .into())
}

fn read_outcome(path: &Path) -> Result<Outcome> {
    let text = record::read_regular(path, MAX_RECORD_BYTES)?;
    if !text.ends_with("end\n") {
        return Err("published round is incomplete".into());
    }
    if text.starts_with("decision=accepted\n") {
        record::parse_accepted(&text)?;
        let advance = match text.lines().find_map(|line| line.strip_prefix("advance=")) {
            Some("true") => true,
            Some("false") => false,
            _ => return Err("published round lacks a continuation decision".into()),
        };
        Ok(Outcome {
            accepted: true,
            advance,
        })
    } else if text.starts_with("decision=rejected\n") {
        Ok(Outcome {
            accepted: false,
            advance: false,
        })
    } else {
        Err("published round lacks an outcome".into())
    }
}
